package client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import javax.xml.namespace.QName;
import javax.xml.ws.Service;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import soa.SOA;

public class SOAClient{

    private static final String RESULT = "entry";

    public static void main(String[] args) throws Exception {

        URL url = new URL("http://localhost:9999/ws/soa?wsdl");

        //1st argument service URI, refer to wsdl document above
        //2nd argument is service name, refer to wsdl document above
        QName qname = new QName("http://soa/", "SOAImplService");

        Service service = Service.create(url, qname);

        SOA soa = service.getPort(SOA.class);

        BufferedReader buffer=new BufferedReader(new InputStreamReader(System.in));
        String line="";
        JSONParser parser = new JSONParser();

        System.out.println("To end the Client, write stop or end...\n");
        System.out.println("Please type in the search tag... \n  ");

        //
        while(true) {
            try {
                line = buffer.readLine();
            } catch (IOException e) {
            }

            if(line.equalsIgnoreCase("stop")||line.equalsIgnoreCase("end")){break;}
            if(!line.equalsIgnoreCase("")){
                line = soa.getWikiEntry(line.toString());
                JSONObject obj = (JSONObject) parser.parse(line);

                int entries = 1;
                while(line.toLowerCase().contains(RESULT.toLowerCase()+entries)){
                    entries++;
                }


                for (int i=1; i<entries;i++)
                    System.out.println(obj.get("entry"+i));

                System.out.println("\nPlease put in a new search question... \n  ");
            }
        }
    }
}
