package soa;

import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import javax.jws.WebService;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

//Service Implementation
@SuppressWarnings("ValidExternallyBoundObject")
@WebService(endpointInterface = "soa.SOA")
public class SOAImpl implements SOA {

    private String ip;

    public SOAImpl(String ip) {
        this.ip=ip;
    }

    @Override
    public String getWikiEntry(String searchString) {
        Connection conn = null;
        Statement stmt = null;
        JSONObject obj = new JSONObject();

        try {
            //Create connection via JDBC
            MysqlDataSource ds = new MysqlDataSource();
            ds.setServerName(ip);
            ds.setDatabaseName("judith");
            ds.setUser("judith");
            ds.setPassword("judith");

            conn = ds.getConnection();

            stmt = conn.createStatement();

            String sql = "Select v.id,v.name,v.text from viki v join tak t where v.id = t.viki_id and t.name like '" + searchString + "'";

            ResultSet rs = stmt.executeQuery(sql);

            int counter = 1;
            while (rs.next()) {
                JSONArray arr = new JSONArray();
                JSONObject entry = new JSONObject();

                entry.put("id", Integer.parseInt(rs.getString("id")));
                entry.put("name", rs.getString("name"));
                entry.put("text", rs.getString("text"));

                arr.add(entry);
                obj.put("entry"+counter,arr);
                counter++;
            }

            //Close all remaining connections
            rs.close();
            stmt.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return obj.toString();
    }
}